package com.codingdojo.movies.controllers;public class CustomErrorController {
}
